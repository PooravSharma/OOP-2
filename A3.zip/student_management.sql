DROP DATABASE IF EXISTS student_management;
CREATE DATABASE student_management;

USE student_management;

CREATE TABLE student_score
(
Subject VARCHAR (50) NOT NULL,
Score INT NOT NULL
);
INSERT INTO student_score
	(Subject, Score)
VALUES
	("English", 95),
	("Math", 100),
	("Science", 89);
	