/*Used to delete database that already exists */
DROP DATABASE IF EXISTS smtbiz;

/*Creates the database */
CREATE DATABASE smtbiz;

/*selects which database to use*/
USE smtbiz;

/*Create table in the database*/
CREATE TABLE customer(
	ID INT PRIMARY KEY NOT NULL,
	Name VARCHAR (50) NOT NULL,
	Email VARCHAR (50) NOT NULL,
	Mobile VARCHAR (50) NOT NULL
);

/*Add values to the table in the database*/
INSERT INTO
	customer (ID, Name, Email, Mobile)
VALUES
	(1234, "Sam", "sam.hall@gmail.com", "42140580"),
	(2346, "Dam", "dam.brook@gmail.com", "42460554"),
	(3464, "Pam", "pam.smith@gmail.com", "42140895"),
	(3897, "Josh", "josh.black@gmail.com", "42934051"),
	(4554, "Ham", "ham.pork@gmail.com", "41437545");

/*Used to search for a specific customer*/
SELECT * FROM customer WHERE ID = 1234;

/*Used to delete a specific customer*/
DELETE FROM	customer WHERE ID = 1234;

/*Used to display a everything in customer table*/
SELECT	* FROM customer;